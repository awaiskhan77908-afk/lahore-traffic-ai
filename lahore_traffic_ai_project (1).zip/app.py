from pathlib import Path

import streamlit as st
import pandas as pd
import joblib

BASE_DIR = Path(__file__).resolve().parent

st.set_page_config(
    page_title="Lahore Traffic AI",
    page_icon="🚦",
    layout="wide"
)

st.title("Lahore Traffic AI")
st.subheader("Traffic Congestion Prediction and Smart Route Support")

st.warning(
    "This is a demonstration using synthetic traffic data, "
    "not live traffic information from Lahore."
)

data_path = BASE_DIR / "lahore_traffic_demo.csv"
model_path = BASE_DIR / "traffic_model.joblib"

if not data_path.exists() or not model_path.exists():
    st.error("Dataset ya trained AI model ki file missing hai.")
    st.stop()

df = pd.read_csv(data_path)
df["timestamp"] = pd.to_datetime(df["timestamp"])

saved = joblib.load(model_path)
model = saved["model"]
features = saved["features"]
road_codes = saved["road_codes"]

roads = sorted(df["road"].unique())
selected_road = st.selectbox("Road select karein", roads)

road_data = df[df["road"] == selected_road].sort_values("timestamp")
latest = road_data.iloc[-1]

hour = int(latest["timestamp"].hour)
day_of_week = int(latest["timestamp"].dayofweek)
previous_speed = float(latest["speed"])
road_id = int(road_codes[selected_road])

input_data = pd.DataFrame([{
    "hour": hour,
    "day_of_week": day_of_week,
    "road_id": road_id,
    "previous_speed": previous_speed
}])[features]

predicted_speed = float(model.predict(input_data)[0])

col1, col2, col3 = st.columns(3)

col1.metric("Latest recorded demo speed", f"{previous_speed:.1f} km/h")
col2.metric("Predicted next speed", f"{predicted_speed:.1f} km/h")

if predicted_speed < 20:
    congestion = "High"
elif predicted_speed < 35:
    congestion = "Moderate"
else:
    congestion = "Low"

col3.metric("Estimated congestion", congestion)

st.markdown("### Road speed history")
st.line_chart(road_data.set_index("timestamp")["speed"])

st.markdown("### Dataset preview")
st.dataframe(df.head(20), use_container_width=True)

st.download_button(
    "Download demo dataset (CSV)",
    data=df.to_csv(index=False).encode("utf-8"),
    file_name="lahore_traffic_demo.csv",
    mime="text/csv"
)

st.caption(
    "Educational prototype only. Predictions are based on synthetic data "
    "and should not be used for real travel decisions."
)
